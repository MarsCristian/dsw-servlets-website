create definer = admin@`%` view view_name as
select `SiteConsultas`.`paciente`.`paciente_id`    AS `paciente_id`,
       `SiteConsultas`.`paciente`.`email`          AS `email`,
       `SiteConsultas`.`paciente`.`senha`          AS `senha`,
       `SiteConsultas`.`paciente`.`cpf`            AS `cpf`,
       `SiteConsultas`.`paciente`.`nome`           AS `nome`,
       `SiteConsultas`.`paciente`.`telefone`       AS `telefone`,
       `SiteConsultas`.`paciente`.`sexo`           AS `sexo`,
       `SiteConsultas`.`paciente`.`dataNascimento` AS `dataNascimento`
from `SiteConsultas`.`paciente`;

